

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import part1Poe.Login;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Hp
 */
public class Testing {
    Login validLogin ;
     Login invalidUsernameLogin;
    Login validPasswordLogin;
     Login invalidPasswordLogin;
    public Testing() {
        
        validLogin = new Login("kyl_1", "Ch&&sec@ke99!", "Angel", "Rambau");
        invalidUsernameLogin = new Login("kyle!!!!!!!", "Ch&&sec@ke99!", "Angel", "Rambau");
        validPasswordLogin = new Login("kyl_1", "Ch&&sec@ke99!", "Angel", "Rambau");
        invalidPasswordLogin = new Login("kyl_1", "password", "Angel", "Rambau");
    }
 
    @Test
    public void testCorrectUsernameFormat() {
        assertTrue(validLogin.checkUserName());
        assertEquals("Welcome Angel Rambau, it is great to see you again.", 
                      validLogin.returnLoginStatus("kyl_1", "Ch&&sec@ke99!"));
    }

   
    @Test
    public void testIncorrectUsernameFormat() {
        assertFalse(invalidUsernameLogin.checkUserName());
        assertEquals("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.",
                      invalidUsernameLogin.registerUser());
    }

   
    @Test
    public void testCorrectPasswordComplexity() {
        assertTrue(validPasswordLogin.checkPasswordComplexity());
       
    }


    @Test
    public void testIncorrectPasswordComplexity() {
        assertFalse(invalidPasswordLogin.checkPasswordComplexity());
     
    }

 
    @Test
    public void testLoginSuccess() {
        assertTrue(validLogin.loginUser("kyl_1", "Ch&&sec@ke99!"));
    }


 
    @Test
    public void testLoginFailed() {
        assertFalse(validLogin.loginUser("kyl_1", "wrongpassword"));
    }
       @Test
    public void testUsernameCorrect() {
        assertTrue(validLogin.checkUserName());
    }


 
    @Test
    public void testUsernameIncorrect() {
        assertFalse(invalidUsernameLogin.checkUserName());
    }
    
         @Test
    public void testPasswordCorrect() {
        assertTrue(validPasswordLogin.checkPasswordComplexity());
    }


 
    @Test
    public void testPasswordIncorrect() {
        assertFalse(invalidPasswordLogin.checkPasswordComplexity());
    }
    
    
    
}
