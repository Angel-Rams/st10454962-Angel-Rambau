/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package part1Poe;

import java.util.Scanner;

/**
 *
 * @author Hp
 */
public class Part1POE {

    public static void main(String[] args) {
      Scanner scanner = new Scanner(System.in);

        System.out.println("Register a new account:");
        System.out.print("Enter username: ");
        String username = scanner.nextLine();

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        System.out.print("Enter first name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter last name: ");
        String lastName = scanner.nextLine();

      
        Login login = new Login(username, password, firstName, lastName);
        String registrationResult = login.registerUser();
        System.out.println(registrationResult);

    
        if (registrationResult.equals("The user has been registered successfully")) {
            System.out.println("\nLogin to your account:");
            System.out.print("Enter username: ");
            String loginUsername = scanner.nextLine();

            System.out.print("Enter password: ");
            String loginPassword = scanner.nextLine();

            String loginStatus = login.returnLoginStatus(loginUsername, loginPassword);
            System.out.println(loginStatus);
        }
    }
}